package com.example.google.Model

class Myplaces {
    var html_attributions:Array<String>? = null
    var status:String? = null
    var next_page_token:String? = null
    var results : Array<Results>? = null
}