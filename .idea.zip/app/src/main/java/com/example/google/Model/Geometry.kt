package com.example.google.Model

class Geometry {
    var location:Location?=null
    var viewport:Viewport?=null
}