package com.example.google.Model

class Close {
    var day:Int=0
    var time:String?=null
}