package com.example.google.Model

class Viewport {
    var northeast:Northeast? = null
    var southwest:Southwest? = null
}