package com.example.google.Model

class Northeast {
    var lat:Double = 0.0
    var lng:Double = 0.0
}