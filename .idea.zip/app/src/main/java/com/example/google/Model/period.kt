package com.example.google.Model

class period {
    var close:Close?=null
    var open:Open?=null
}