package com.example.google.Model

class OpeningHours {
    var open_now:Boolean = false
    var periods:Array<period>?=null
    var weekday_text:Array<String>?=null
}