package com.example.google.Model

class PlusCode {
    var compound_code:String?=null
    var global_code:String?=null
}