package com.example.google.Model

class AddressComponent {
    var long_name:String?=null
    var short_name:String?=null
    var types:Array<String>?=null
}