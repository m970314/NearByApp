package com.example.google.Model

class PlaceDetail {
    var status:String?=null
    var result:Results?=null
    var html_attributions:Array<String>?=null

}