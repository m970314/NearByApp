package com.example.google.Model

class Open {
    var day:Int=0
    var time:String?=null
}