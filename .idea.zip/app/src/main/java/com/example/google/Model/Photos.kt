package com.example.google.Model

class Photos {
    var height: Int = 0
    var html_attributions: Array<String>? = null
    var photo_reference:String?=null
    var width:Int = 0
}