package com.example.google.Model

class ReView {
    var author_name:String?=null
    var author_url:String?=null
    var language:String?=null
    var profile_photo_url:String?=null
    var rating:Int=0
    var relative_time_description:String?=null
    var text:String?=null
    var time:Int=0
}